package login;

import java.util.ArrayList;

public class List {
	String [] userList;
	//ArrayList<String> userList = new ArrayList<String>();
	public String[] getUserList() {
		return userList;
	}
	public void setUserList(String[] userList) {
		this.userList = userList;
	}
}
